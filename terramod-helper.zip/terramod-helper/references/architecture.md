# TerrariaMine-MultiLoader 项目架构参考

## 基本信息
- **MOD ID**: `terrariamod`
- **包名**: `com.ricky.terrariamod`
- **Minecraft 版本**: 1.20.1
- **加载器**: Fabric + Forge (MultiLoader)
- **构建系统**: Gradle

## 模块结构

| 模块 | 目录 | 职责 |
|------|------|------|
| **common** | `common/src/main/java/com/ricky/terrariamod/` | 所有核心逻辑：Item/Block/Entity 定义、AI、模型、渲染器 |
| **fabric** | `fabric/src/main/java/com/ricky/terrariamod/` | Fabric 入口、属性注册、渲染器绑定 |
| **forge** | `forge/src/main/java/com/ricky/terrariamod/` | Forge 入口、事件注册、数据生成器 |

## 注册表抽象机制

通过 `Services` + Java SPI 实现跨平台：
```
RegistryProvider<T> (接口, common)
├── FabricRegistryProvider  → 直接 Registry.register()
└── ForgeRegistryProvider   → 委托 DeferredRegister
```

注册方法统一为：
```java
RegistryProvider<Item> ITEMS = RegistryProvider.get(Registries.ITEM, Constants.MOD_ID);
RegistryObject<Item> MY_ITEM = ITEMS.register("my_item", () -> new Item(...));
```

## 资源文件路径

```
common/src/main/resources/assets/terrariamod/
├── textures/
│   ├── item/{item_id}.png          ← 物品贴图 (16x16)
│   ├── block/{block_id}.png        ← 方块贴图 (16x16)
│   ├── entity/{entity_name}.png    ← 实体贴图
│   └── models/armor/{material}_layer_1.png / _layer_2.png ← 护甲模型贴图
├── models/item/                    ← 物品模型 JSON（3D武器需手动放）
├── models/block/                   ← 方块模型 JSON
├── blockstates/                    ← 方块状态 JSON
└── lang/
    ├── en_us.json
    ├── ja_jp.json
    ├── zh_cn.json
    └── fr_fr.json
```

## 语言文件 key 格式

- 物品: `"item.terrariamod.{item_id}": "显示名称"`
- 方块: `"block.terrariamod.{block_id}": "显示名称"`
- 实体: `"entity.terrariamod.{entity_id}": "显示名称"`

---

## Item 注册流程

### 核心文件
- `common/.../item/ModItems.java`
- `common/.../item/ModCreativeTabs.java`
- `common/.../item/tool/ModToolMaterial.java`（工具材料）
- `common/.../item/armor/ModArmorMaterials.java`（护甲材料）
- `common/.../item/armor/ModArmorItem.java`（护甲套装效果）

### 添加新物品的检查清单

1. **`ModItems.java`** — 注册 `RegistryObject<Item>`
2. **`ModCreativeTabs.java`** — 添加到对应标签页（armor_tab / tool_tab / item_tab / block_tab）
3. **Forge `ModItemModelProvider.java`** — `simpleItem()` 或 `handheldItem()`
4. **`textures/item/{id}.png`** — 物品贴图
5. **`lang/*.json`** — 4 种语言翻译（en_us, ja_jp, zh_cn, fr_fr）

### 武器类型

| 类型 | 继承类 | 接口 | 示例 |
|------|--------|------|------|
| 近战剑 | `SwordItem` | - | COBALT_SWORD |
| 工具镐 | `ModPickaxeItem`→`DiggerItem` | - | COBALT_PICKAXE |
| 工具斧 | `ModAxeItem`→`AxeItem` | - | COBALT_AXE |
| 工具铲 | `ShovelItem` | - | COBALT_SHOVEL |
| 枪械 | `SwordItem` | `AttackableItem` | HANDGUN |
| 魔法杖 | `SwordItem` | `AttackableItem` | AMETHYST_STAFF |
| 火箭筒 | `BowItem` | - | ROCKET_LAUNCHER |

### 护甲系统

护甲由两部分组成：
- **头盔** → `ModArmorItem`（包含套装效果判定逻辑）
- **胸甲/腿/靴** → 原版 `ArmorItem`

套装效果在 `ModArmorItem.MATERIAL_TO_EFFECT_MAP` 中定义：
```java
.put(ModArmorMaterials.COBALT, new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 219, 1, false, false, true))
```

护甲材料参数（ModArmorMaterials 枚举）：
```
(name, durabilityMultiplier, protectionAmounts[boots,legs,chest,head], enchantability, equipSound, toughness, knockbackResistance, repairIngredient)
```

### 工具材料参数（ModToolMaterial 枚举）：
```
(miningLevel, itemDurability, miningSpeed, attackDamage, enchantability, repairIngredient)
```

---

## Block 注册流程

### 核心文件
- `common/.../block/ModBlocks.java`

### 注册方法
```java
public static final Supplier<Block> MY_BLOCK = registerBlockWithItem("my_block",
        () -> new Block(BlockBehaviour.Properties.copy(Blocks.STONE)));
```
此方法同时注册 Block 和 BlockItem。

### 添加新方块的检查清单

1. **`ModBlocks.java`** — `registerBlockWithItem()`
2. **`ModCreativeTabs.java`** — 添加到 block_tab
3. **Forge `ModBlockStateProvider.java`** — 方块状态/模型
4. **Forge `ModLootTableProvider.java`** — 战利品表（dropSelf / createOreDrop / createLeavesDrops）
5. **Forge `ModBlockTagProvider.java`** — 标签（可选）
6. **Forge `ModRecipeProvider.java`** — 合成配方（可选）
7. **`textures/block/{id}.png`** — 方块贴图
8. **`lang/*.json`** — 4 种语言翻译
9. **Fabric `TerrariaModClient`** — 如需透明渲染（`RenderType.cutout()`）

### 方块类型

| 类型 | 实现类 | 示例 |
|------|--------|------|
| 普通方块 | `Block(Properties.copy(Blocks.IRON_BLOCK))` | COBALT_BLOCK |
| 矿石 | `DropExperienceBlock(Properties.copy(Blocks.DIAMOND_ORE).strength(50f, 1200f), UniformInt.of(2, 5))` | COBALT_ORE |
| 沙子 | `SandBlock(颜色ID, Properties.copy(Blocks.SAND))` | EBON_SAND |
| 冰 | `IceBlock(Properties.copy(Blocks.ICE))` | EBON_ICE |
| 原木 | `RotatedPillarBlock(Properties.copy(Blocks.OAK_LOG))` | EBON_LOG |
| 树叶 | `RotatedPillarBlock(Properties.copy(Blocks.OAK_LEAVES).noOcclusion())` | EBON_LEAVES |
| 花/蘑菇 | `FlowerBlock(MobEffects.HARM, 10, Properties.copy(Blocks.ALLIUM))` | DEATH_WEED |
| 发光方块 | `Block(Properties.copy(...).lightLevel(state -> 6))` | GLOWING_MUSHROOM_BLOCK |

---

## Entity 注册流程

### 核心文件
- `common/.../entity/ModEntities.java`（注册 EntityType）
- `fabric/.../TerrariaMod.java`（Fabric 属性注册）
- `forge/.../event/ModEventBusEvents.java`（Forge 属性注册）
- `fabric/.../TerrariaModClient.java`（Fabric 渲染器绑定）
- `forge/.../event/ClientModLifecycleEvents.java`（Forge 渲染器绑定）

### 添加新实体的完整检查清单

1. **Entity 类** (common) — 继承合适的父类, 定义 `createAttributes()`, `registerGoals()`
2. **Renderer 类** (common) — 继承 `MobRenderer`/`SlimeRenderer`/`HumanoidMobRenderer` 等
3. **Model 类** (common, 如需自定义模型) — 定义 `LAYER_LOCATION`, `createBodyLayer()`
4. **`ModEntities.java`** — 注册 `EntityType`
5. **Fabric `TerrariaMod.java`** — `FabricDefaultAttributeRegistry.register(entity, XxxEntity.createAttributes())`
6. **Fabric `TerrariaModClient.java`** — `EntityRendererRegistry.register()` + `EntityModelLayerRegistry`（自定义模型需要）
7. **Forge `ModEventBusEvents.java`** — `event.put(entity, XxxEntity.createAttributes().build())`
8. **Forge `ClientModLifecycleEvents.java`** — `EntityRenderers.register()` + `event.registerLayerDefinition()`（自定义模型需要）
9. **`textures/entity/{name}.png`** — 实体贴图
10. **`lang/*.json`** — 4 种语言翻译

### 实体类型模式

| 基类 | 需要的文件 | 示例 |
|------|-----------|------|
| Slime | Entity + Renderer（2个文件） | IceSlimeEntity |
| Skeleton | Entity + Renderer（2个文件，用 HumanoidMobRenderer） | AngryBonesEntity |
| Zombie | Entity + Renderer（2个文件） | MummyEntity |
| Bat | Entity + Renderer（2个文件） | LavaBatEntity |
| FlyingMob | Entity + Model + Renderer（3个文件） | DemonEyeEntity |

### FlyingMob 必须组件
- Entity 类中: `this.moveControl = new FlyMoveControl(this);`
- registerGoals: `FlyRandomlyGoal` + `TrackPlayerGoal`

---

## Forge 数据生成器

### 物品模型
```java
// 普通物品（item/generated）
simpleItem(ModItems.MY_ITEM);
// 手持物品（item/handheld，用于工具/武器）
handheldItem(ModItems.MY_SWORD);
```

### 方块状态
```java
blockWithItem(ModBlocks.MY_BLOCK);           // 普通 cubeAll
logBlock(block);                             // 原木
stairsBlock(block, texture);                 // 楼梯
slabBlock(block, fullTexture, halfTexture);  // 台阶
plantBlockWithItem(block);                   // 植物 (cross + cutout)
```

### 配方
```java
generateToolRecipes(exporter, ingot, materialName);   // 工具四件套
generateArmorRecipes(exporter, ingot, materialName);   // 护甲四件套
generateCompactingRecipes(exporter, ingot, block);     // 压缩/逆压缩
```

### 战利品表
```java
dropSelf(block);                                // 掉落自身
createOreDrop(block, rawItem);                  // 矿石掉落
createLeavesDrops(leaves, sapling, chance);     // 树叶掉落
```
