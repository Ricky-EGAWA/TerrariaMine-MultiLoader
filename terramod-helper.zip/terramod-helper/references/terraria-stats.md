# Terraria 官方数值参考（1.4.4）

## 工具材料等级（ModToolMaterial）

| 材料 | 挖掘等级 | 耐久 | 挖掘速度 | 攻击伤害 | 附魔值 |
|------|---------|------|---------|---------|--------|
| COBALT_INGOT | 5 | 2200 | 11f | 5f | 20 |
| ORICHALCUM_INGOT | 6 | 2500 | 13f | 6f | 23 |
| ADAMANTITE_INGOT | 7 | 3000 | 15f | 8f | 25 |
| HELLSTONE_INGOT | 4 | 1800 | 10f | 4f | 20 |

## 护甲材料（ModArmorMaterials）

格式: `(name, durabilityMult, [boots,legs,chest,head], enchant, sound, toughness, knockbackRes, repairItem)`

| 材料 | 耐久倍率 | 防护值 [靴/裤/胸/头] | 韧性 | 击退抗性 | 修复材料 |
|------|---------|---------------------|------|---------|---------| 
| OAK | 5 | [1,2,2,1] | 0 | 0 | OAK_LOG |
| COPPER | 12 | [2,5,4,2] | 0 | 0 | COPPER_INGOT |
| OBSIDIAN | 35 | [3,8,6,3] | 0 | 0 | OBSIDIAN |
| CACTUS | 8 | [2,5,3,1] | 0 | 0 | CACTUS |
| PUMPKIN | 8 | [2,5,3,1] | 0 | 0 | PUMPKIN |
| GLASS | 25 | [2,0,0,0] | 0 | 0 | GLASS（仅头盔） |
| NIGHT | 25 | [2,0,0,0] | 0 | 0 | GLASS（仅头盔） |
| COBALT | 35 | [6,8,6,5] | 4 | 0.1 | COBALT_INGOT |
| ORICHALCUM | 45 | [7,12,9,2] | 4 | 0.2 | ORICHALCUM_INGOT |
| ADAMANTITE | 50 | [8,16,12,0] | 5 | 0.3 | ADAMANTITE_INGOT |
| HELLSTONE | 40 | [3,8,6,3] | 3 | 0.1 | HELLSTONE_INGOT |

## 套装效果（ModArmorItem.MATERIAL_TO_EFFECT_MAP）

| 材料 | 效果 | 条件 |
|------|------|------|
| COBALT | 速度 II (MOVEMENT_SPEED) | 全套四件 |
| ORICHALCUM | 生命提升 II (HEALTH_BOOST) | 全套四件 |
| ADAMANTITE | 力量 II (DAMAGE_BOOST) | 全套四件 |
| HELLSTONE | 防火 II (FIRE_RESISTANCE) | 全套四件 |
| OBSIDIAN | 防火 II (FIRE_RESISTANCE) | 全套四件 |
| PUMPKIN | 力量 II (DAMAGE_BOOST) | 全套四件 |
| GLASS | 水下呼吸 II (WATER_BREATHING) | 仅头盔 |
| NIGHT | 夜视 II (NIGHT_VISION) | 仅头盔 |

## 已有武器伤害值

| 武器 | 类型 | SwordItem 附加伤害 | 攻速 |
|------|------|-------------------|------|
| Cobalt Sword | 剑 | 7 | -2.4f |
| Orichalcum Sword | 剑 | 9 | -2.4f |
| Adamantite Sword | 剑 | 13 | -2.4f |
| Hellstone Sword | 剑 | 6 | -2.4f |
| Cobalt Pickaxe | 镐 | 2 | -3f |
| Cobalt Axe | 斧 | 7 | -3f |
| Cobalt Shovel | 铲 | 1 | -3f |

## 已有实体属性

| 实体 | HP | 速度 | 护甲 | 攻击力 | 类型 |
|------|-----|------|------|--------|------|
| DemonEye | 15 | 0.2 | 0.5 | 7 | FlyingMob |
| IceSlime | 24 | 0.2 | 0 | 10(attr)/6(actual) | Slime |
| AngryBones | 50 | 0.25 | 2 | 7.5 | Skeleton |
| EyeOfCthulhu P1 | 150 | 0.2 | 8 | 7 | FlyingMob (Boss) |
| EyeOfCthulhu P2 | 150 | 0.3 | 8 | 11 | FlyingMob (Boss) |
| Mummy | - | - | - | - | Zombie |

## 创造模式标签页

| 标签页 | 注册名 | 内容 |
|--------|--------|------|
| armor_tab | 护甲 | 所有防具 |
| tool_tab | 工具与武器 | 剑/镐/斧/铲/法杖/枪/弹药 |
| item_tab | 材料物品 | 锭/原石/特殊物品 |
| block_tab | 方块 | 所有方块 |
