// ===== Slime 类型怪物模板 =====
// 文件1: common/.../entity/monster/slime_type/{{name}}/{{Name}}Entity.java
package com.ricky.terrariamod.entity.monster.slime_type.{{name}};

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.level.Level;

public class {{Name}}Entity extends Slime {
    public {{Name}}Entity(EntityType<? extends Slime> entityType, Level world) {
        super(entityType, world);
        this.setSize(2, true);
        this.refreshDimensions();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, {{maxHealth}})
                .add(Attributes.MOVEMENT_SPEED, {{moveSpeed}}f)
                .add(Attributes.FOLLOW_RANGE, 10.0)
                .add(Attributes.ARMOR, {{armor}}f)
                .add(Attributes.ATTACK_DAMAGE, {{attackDamage}});
    }

    @Override
    public void remove(RemovalReason reason) {
        this.setSize(1, true);
        super.remove(reason);
    }

    @Override
    public void setSize(int size, boolean resetHealth) {
        super.setSize(2, resetHealth);
        this.refreshDimensions();
        this.getAttribute(Attributes.MAX_HEALTH).setBaseValue({{maxHealth}});
        this.setHealth({{maxHealth}});
        this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue({{actualDamage}});
        this.getAttribute(Attributes.FOLLOW_RANGE).setBaseValue(40);
    }
}

// 文件2: common/.../entity/monster/slime_type/{{name}}/{{Name}}Renderer.java
package com.ricky.terrariamod.entity.monster.slime_type.{{name}};

import com.ricky.terrariamod.Constants;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.SlimeRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.Slime;

public class {{Name}}Renderer extends SlimeRenderer {
    private static final ResourceLocation TEXTURE = new ResourceLocation(Constants.MOD_ID, "textures/entity/{{texture_name}}.png");

    public {{Name}}Renderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    public ResourceLocation getTextureLocation(Slime entity) {
        return TEXTURE;
    }
}


// ===== Skeleton 类型怪物模板 =====
// 文件1: common/.../entity/monster/skeleton_type/{{name}}/{{Name}}Entity.java
package com.ricky.terrariamod.entity.monster.skeleton_type.{{name}};

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Skeleton;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public class {{Name}}Entity extends Skeleton {
    private boolean hasInitializedEquipment = false;

    public {{Name}}Entity(EntityType<? extends Skeleton> entityType, Level level) {
        super(entityType, level);
    }

    @Override
    protected boolean isSunBurnTick() {
        return false; // 不会被阳光燃烧
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.FOLLOW_RANGE, 35.0D)
                .add(Attributes.MOVEMENT_SPEED, {{moveSpeed}}F)
                .add(Attributes.ATTACK_DAMAGE, {{attackDamage}}D)
                .add(Attributes.ARMOR, {{armor}}D)
                .add(Attributes.MAX_HEALTH, {{maxHealth}}D)
                .add(Attributes.KNOCKBACK_RESISTANCE, {{knockbackRes}}D)
                .add(Attributes.SPAWN_REINFORCEMENTS_CHANCE);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && !hasInitializedEquipment) {
            setupEquipment();
            hasInitializedEquipment = true;
        }
    }

    private void setupEquipment() {
        int armorColor = DyeColor.{{DYE_COLOR}}.getTextColor();
        // 设置染色皮革防具
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack armor = new ItemStack(switch (slot) {
                case HEAD -> Items.LEATHER_HELMET;
                case CHEST -> Items.LEATHER_CHESTPLATE;
                case LEGS -> Items.LEATHER_LEGGINGS;
                case FEET -> Items.LEATHER_BOOTS;
                default -> Items.AIR;
            });
            CompoundTag tag = armor.getOrCreateTag();
            CompoundTag display = tag.getCompound("display");
            display.putInt("color", armorColor);
            tag.put("display", display);
            this.setItemSlot(slot, armor);
            this.setDropChance(slot, 0.0F);
        }
        this.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
    }
}

// 文件2: Renderer 使用 HumanoidMobRenderer + 骷髅贴图
package com.ricky.terrariamod.entity.monster.skeleton_type.{{name}};

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.Skeleton;

public class {{Name}}Renderer extends HumanoidMobRenderer<Skeleton, HumanoidModel<Skeleton>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("minecraft", "textures/entity/skeleton/skeleton.png");

    public {{Name}}Renderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.SKELETON)), 0.5F);
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(context.bakeLayer(ModelLayers.ZOMBIE_INNER_ARMOR)),
                new HumanoidModel<>(context.bakeLayer(ModelLayers.ZOMBIE_OUTER_ARMOR)),
                context.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(Skeleton entity) { return TEXTURE; }

    @Override
    protected boolean isShaking(Skeleton entity) { return false; }
}


// ===== Zombie 类型怪物模板 =====
// 文件1: common/.../entity/monster/zombie_type/{{name}}/{{Name}}Entity.java
package com.ricky.terrariamod.entity.monster.zombie_type.{{name}};

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;

public class {{Name}}Entity extends Zombie {
    public {{Name}}Entity(EntityType<? extends Zombie> entityType, Level level) {
        super(entityType, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.FOLLOW_RANGE, 35.0D)
                .add(Attributes.MOVEMENT_SPEED, {{moveSpeed}}D)
                .add(Attributes.ATTACK_DAMAGE, {{attackDamage}}D)
                .add(Attributes.ARMOR, {{armor}}D)
                .add(Attributes.MAX_HEALTH, {{maxHealth}}D)
                .add(Attributes.SPAWN_REINFORCEMENTS_CHANCE);
    }
}

// 文件2: Renderer
package com.ricky.terrariamod.entity.monster.zombie_type.{{name}};

import com.ricky.terrariamod.Constants;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.Zombie;

public class {{Name}}Renderer extends ZombieRenderer {
    private static final ResourceLocation TEXTURE = new ResourceLocation(Constants.MOD_ID, "textures/entity/{{texture_name}}.png");

    public {{Name}}Renderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public ResourceLocation getTextureLocation(Zombie entity) { return TEXTURE; }
}


// ===== FlyingMob 类型怪物模板（需要自定义模型）=====
// 文件1: Entity
package com.ricky.terrariamod.entity.monster.flying_type.{{name}};

import com.ricky.terrariamod.entity.monster.flying_type.FlyMoveControl;
import com.ricky.terrariamod.entity.monster.flying_type.FlyRandomlyGoal;
import com.ricky.terrariamod.entity.monster.flying_type.TrackPlayerGoal;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

public class {{Name}}Entity extends FlyingMob {
    public {{Name}}Entity(EntityType<? extends FlyingMob> type, Level level) {
        super(type, level);
        this.moveControl = new FlyMoveControl(this);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, {{maxHealth}})
                .add(Attributes.MOVEMENT_SPEED, {{moveSpeed}}f)
                .add(Attributes.ARMOR, {{armor}}f)
                .add(Attributes.ATTACK_DAMAGE, {{attackDamage}});
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(5, new FlyRandomlyGoal(this));
        this.targetSelector.addGoal(1, new TrackPlayerGoal(this));
    }
}

// 文件2: Renderer（使用自定义 Model）
package com.ricky.terrariamod.entity.monster.flying_type.{{name}};

import com.ricky.terrariamod.Constants;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;

public class {{Name}}Renderer extends MobRenderer<{{Name}}Entity, {{Name}}Model<{{Name}}Entity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(Constants.MOD_ID, "textures/entity/{{texture_name}}.png");

    public {{Name}}Renderer(EntityRendererProvider.Context context) {
        super(context, new {{Name}}Model<>(context.bakeLayer({{Name}}Model.LAYER_LOCATION)), {{shadowRadius}}f);
    }

    @Override
    public @NotNull ResourceLocation getTextureLocation(@NotNull {{Name}}Entity entity) { return TEXTURE; }
}

// 文件3: Model（需要使用 BlockBench 导出的数据填充 createBodyLayer）
package com.ricky.terrariamod.entity.monster.flying_type.{{name}};

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.ricky.terrariamod.Constants;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import org.jetbrains.annotations.NotNull;

public class {{Name}}Model<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
            new ResourceLocation(Constants.MOD_ID, "{{model_id}}"), "main");
    private final ModelPart root;

    public {{Name}}Model(ModelPart root) {
        this.root = root.getChild("{{root_part_name}}");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.getRoot();
        // TODO: 从 BlockBench 导出的模型数据填充此处
        return LayerDefinition.create(meshdefinition, {{textureWidth}}, {{textureHeight}});
    }

    @Override
    public void setupAnim(@NotNull T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {}

    @Override
    public void renderToBuffer(@NotNull PoseStack poseStack, @NotNull VertexConsumer buffer, int light, int overlay, float r, float g, float b, float a) {
        this.root.render(poseStack, buffer, light, overlay, r, g, b, a);
    }
}


// ===== Bat 类型怪物模板 =====
package com.ricky.terrariamod.entity.monster.bat_type.{{name}};

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ambient.Bat;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

public class {{Name}}Entity extends Bat {
    public {{Name}}Entity(EntityType<? extends Bat> entityType, Level level) {
        super(entityType, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, {{maxHealth}})
                .add(Attributes.MOVEMENT_SPEED, {{moveSpeed}}f)
                .add(Attributes.ATTACK_DAMAGE, {{attackDamage}});
    }
}

// Bat Renderer
package com.ricky.terrariamod.entity.monster.bat_type.{{name}};

import com.ricky.terrariamod.Constants;
import net.minecraft.client.renderer.entity.BatRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.ambient.Bat;

public class {{Name}}Renderer extends BatRenderer {
    private static final ResourceLocation TEXTURE = new ResourceLocation(Constants.MOD_ID, "textures/entity/{{texture_name}}.png");

    public {{Name}}Renderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public ResourceLocation getTextureLocation(Bat entity) { return TEXTURE; }
}
