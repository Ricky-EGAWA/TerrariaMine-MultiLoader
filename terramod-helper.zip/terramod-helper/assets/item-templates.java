// ===== 基础剑（SwordItem）模板 =====
// 文件位置: common/src/main/java/com/ricky/terrariamod/item/ModItems.java（添加到 tool & weapon region）
// 参数说明: SwordItem(Tier, 附加伤害, 攻速, Properties)
// 攻速标准: 剑=-2.4f, 快速=-2.0f, 慢=-2.8f

public static final RegistryObject<Item> {{MATERIAL_UPPER}}_SWORD = ITEMS.register("{{material_lower}}_sword",
        () -> new SwordItem(ModToolMaterial.{{MATERIAL_UPPER}}_INGOT, {{damage}}, -2.4f, new Item.Properties()));


// ===== 工具四件套模板 =====
// 镐
public static final RegistryObject<Item> {{MATERIAL_UPPER}}_PICKAXE = ITEMS.register("{{material_lower}}_pickaxe",
        () -> new ModPickaxeItem(ModToolMaterial.{{MATERIAL_UPPER}}_INGOT, 2, -3f, new Item.Properties()));
// 斧
public static final RegistryObject<Item> {{MATERIAL_UPPER}}_AXE = ITEMS.register("{{material_lower}}_axe",
        () -> new ModAxeItem(ModToolMaterial.{{MATERIAL_UPPER}}_INGOT, 7, -3f, new Item.Properties()));
// 铲
public static final RegistryObject<Item> {{MATERIAL_UPPER}}_SHOVEL = ITEMS.register("{{material_lower}}_shovel",
        () -> new ShovelItem(ModToolMaterial.{{MATERIAL_UPPER}}_INGOT, 1, -3f, new Item.Properties()));


// ===== 防具四件套模板 =====
// 头盔（使用 ModArmorItem，包含套装效果逻辑）
public static final RegistryObject<Item> {{MATERIAL_UPPER}}_HELMET = ITEMS.register("{{material_lower}}_helmet",
        () -> new ModArmorItem(ModArmorMaterials.{{MATERIAL_UPPER}}, ArmorItem.Type.HELMET, new Item.Properties()));
// 胸甲
public static final RegistryObject<Item> {{MATERIAL_UPPER}}_CHESTPLATE = ITEMS.register("{{material_lower}}_chestplate",
        () -> new ArmorItem(ModArmorMaterials.{{MATERIAL_UPPER}}, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
// 护腿
public static final RegistryObject<Item> {{MATERIAL_UPPER}}_LEGGINGS = ITEMS.register("{{material_lower}}_leggings",
        () -> new ArmorItem(ModArmorMaterials.{{MATERIAL_UPPER}}, ArmorItem.Type.LEGGINGS, new Item.Properties()));
// 靴子
public static final RegistryObject<Item> {{MATERIAL_UPPER}}_BOOTS = ITEMS.register("{{material_lower}}_boots",
        () -> new ArmorItem(ModArmorMaterials.{{MATERIAL_UPPER}}, ArmorItem.Type.BOOTS, new Item.Properties()));


// ===== 基础材料物品模板 =====
public static final RegistryObject<Item> {{ITEM_UPPER}} = ITEMS.register("{{item_lower}}",
        () -> new Item(new Item.Properties()));


// ===== 工具材料枚举模板 =====
// 添加到 ModToolMaterial.java 枚举中
// 参数: (miningLevel, itemDurability, miningSpeed, attackDamage, enchantability, repairIngredient)
{{MATERIAL_UPPER}}_INGOT({{miningLevel}}, {{durability}}, {{miningSpeed}}f, {{attackDamage}}f, {{enchantability}},
        () -> Ingredient.of(ModItems.{{MATERIAL_UPPER}}_INGOT.get())),


// ===== 护甲材料枚举模板 =====
// 添加到 ModArmorMaterials.java 枚举中
// 参数: (name, durabilityMultiplier, protectionAmounts[boots,legs,chest,head], enchantability, equipSound, toughness, knockbackResistance, repairIngredient)
{{MATERIAL_UPPER}}("{{material_lower}}", {{durabilityMult}}, new int[] { {{boots}},{{legs}},{{chest}},{{head}} }, {{enchant}},
        SoundEvents.ARMOR_EQUIP_NETHERITE, {{toughness}}f, {{knockbackRes}}f, () -> Ingredient.of(ModItems.{{MATERIAL_UPPER}}_INGOT.get())),


// ===== 枪械武器模板 =====
// 文件位置: common/.../item/weapon/gun/{{Name}}Item.java
package com.ricky.terrariamod.item.weapon.gun;

import com.ricky.terrariamod.entity.projectile.ammo.musket_ball.MusketBallEntity;
import com.ricky.terrariamod.item.ModItems;
import com.ricky.terrariamod.item.weapon.AttackableItem;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.Level;

public class {{Name}}Item extends SwordItem implements AttackableItem {
    public {{Name}}Item(Properties properties) {
        super(Tiers.IRON, {{meleeDamage}}, -2.4f, properties);
    }

    @Override
    public void attack(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide) {
            ItemStack ammo = findMusketBall(player);
            if (player.getAbilities().instabuild || ammo != null) {
                if (!player.getAbilities().instabuild) {
                    ammo.shrink(1);
                }
                shoot(level, player, hand);
            }
        }
    }

    private static Projectile createBullet(Level level, LivingEntity shooter) {
        MusketBallEntity bullet = new MusketBallEntity(level, shooter);
        bullet.shootFromRotation(shooter, shooter.getXRot(), shooter.getYRot(), 0.0F, {{bulletSpeed}}F, 1.0F);
        bullet.setCritArrow(false);
        bullet.setPierceLevel((byte) 0);
        bullet.pickup = AbstractArrow.Pickup.DISALLOWED;
        return bullet;
    }

    private static void shoot(Level level, LivingEntity shooter, InteractionHand hand) {
        Projectile bullet = createBullet(level, shooter);
        if (shooter instanceof ServerPlayer player) {
            ItemStack gun = player.getItemInHand(hand);
            gun.hurt(1, player.getRandom(), player);
        }
        level.addFreshEntity(bullet);
        level.playSound(null, shooter.getX(), shooter.getY(), shooter.getZ(),
                SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.7F, 1.0F);
    }

    private static ItemStack findMusketBall(Player player) {
        for (ItemStack stack : player.getInventory().items) {
            if (stack.is(ModItems.MUSKET_BALL.get())) return stack;
        }
        return null;
    }
}


// ===== 魔法杖武器模板 =====
// 文件位置: common/.../item/weapon/magic/{{Name}}Item.java
package com.ricky.terrariamod.item.weapon.magic;

import com.ricky.terrariamod.entity.projectile.magic.MagicBallEntity;
import com.ricky.terrariamod.item.weapon.AttackableItem;
import com.ricky.terrariamod.util.ManaUtil;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.Level;

public class {{Name}}Item extends SwordItem implements AttackableItem {
    public {{Name}}Item(Properties properties) {
        super(Tiers.WOOD, {{meleeDamage}}, -2.4f, properties);
    }

    @Override
    public void attack(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide) {
            if (ManaUtil.useMana(player, {{manaCost}})) {
                ItemStack stack = player.getItemInHand(hand);
                stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
                MagicBallEntity ball = new MagicBallEntity(level, player, stack, 0, 0, {{damage}}, {{r}}f, {{g}}f, {{b}}f);
                ball.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, {{speed}}F, 0F);
                if (player.getAbilities().instabuild) {
                    ball.pickup = AbstractArrow.Pickup.DISALLOWED;
                }
                level.addFreshEntity(ball);
            }
        }
    }
}
