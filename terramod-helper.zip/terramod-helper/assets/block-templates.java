// ===== 普通方块模板 =====
// 文件位置: common/.../block/ModBlocks.java

// 金属方块
public static final Supplier<Block> {{MATERIAL_UPPER}}_BLOCK = registerBlockWithItem("{{material_lower}}_block",
        () -> new Block(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));

// 矿石方块
public static final Supplier<Block> {{MATERIAL_UPPER}}_ORE = registerBlockWithItem("{{material_lower}}_ore",
        () -> new DropExperienceBlock(BlockBehaviour.Properties.copy(Blocks.DIAMOND_ORE).strength(50f, 1200f), UniformInt.of(2, 5)));

// 深层矿石
public static final Supplier<Block> DEEPSLATE_{{MATERIAL_UPPER}}_ORE = registerBlockWithItem("deepslate_{{material_lower}}_ore",
        () -> new DropExperienceBlock(BlockBehaviour.Properties.copy(Blocks.DIAMOND_ORE).strength(50f, 1200f), UniformInt.of(2, 5)));


// ===== 生物群系石头/沙子/冰模板 =====
public static final Supplier<Block> {{BIOME_UPPER}}_STONE = registerBlockWithItem("{{biome_lower}}_stone",
        () -> new Block(BlockBehaviour.Properties.copy(Blocks.STONE)));

public static final Supplier<Block> {{BIOME_UPPER}}_SAND = registerBlockWithItem("{{biome_lower}}_sand",
        () -> new SandBlock({{colorId}}, BlockBehaviour.Properties.copy(Blocks.SAND)));

public static final Supplier<Block> {{BIOME_UPPER}}_ICE = registerBlockWithItem("{{biome_lower}}_ice",
        () -> new IceBlock(BlockBehaviour.Properties.copy(Blocks.ICE)));


// ===== 木材套件模板（原木/木板/树叶/树苗） =====
public static final Supplier<Block> {{TREE_UPPER}}_LOG = registerBlockWithItem("{{tree_lower}}_log",
        () -> new RotatedPillarBlock(BlockBehaviour.Properties.copy(Blocks.OAK_LOG)));
public static final Supplier<Block> {{TREE_UPPER}}_WOOD = registerBlockWithItem("{{tree_lower}}_wood",
        () -> new RotatedPillarBlock(BlockBehaviour.Properties.copy(Blocks.OAK_WOOD)));
public static final Supplier<Block> STRIPPED_{{TREE_UPPER}}_LOG = registerBlockWithItem("stripped_{{tree_lower}}_log",
        () -> new RotatedPillarBlock(BlockBehaviour.Properties.copy(Blocks.STRIPPED_OAK_LOG)));
public static final Supplier<Block> {{TREE_UPPER}}_PLANKS = registerBlockWithItem("{{tree_lower}}_planks",
        () -> new RotatedPillarBlock(BlockBehaviour.Properties.copy(Blocks.OAK_PLANKS)));
public static final Supplier<Block> {{TREE_UPPER}}_LEAVES = registerBlockWithItem("{{tree_lower}}_leaves",
        () -> new RotatedPillarBlock(BlockBehaviour.Properties.copy(Blocks.OAK_LEAVES).noOcclusion()));


// ===== 植物方块模板 =====
public static final Supplier<Block> {{PLANT_UPPER}} = registerBlockWithItem("{{plant_lower}}",
        () -> new FlowerBlock(MobEffects.{{effect}}, {{duration}}, BlockBehaviour.Properties.copy(Blocks.ALLIUM)));
public static final Supplier<Block> POTTED_{{PLANT_UPPER}} = registerBlockWithItem("potted_{{plant_lower}}",
        () -> new FlowerPotBlock({{PLANT_UPPER}}.get(), BlockBehaviour.Properties.copy(Blocks.POTTED_ALLIUM).noOcclusion()));


// ===== 发光方块模板 =====
public static final Supplier<Block> {{BLOCK_UPPER}} = registerBlockWithItem("{{block_lower}}",
        () -> new Block(BlockBehaviour.Properties.copy(Blocks.STONE).lightLevel(state -> {{lightLevel}})));


// ===== 楼梯/台阶/栅栏等建筑方块模板 =====
public static final Supplier<Block> {{PREFIX_UPPER}}_STAIRS = registerBlockWithItem("{{prefix_lower}}_stairs",
        () -> new ModStairBlock(ModBlocks.{{PREFIX_UPPER}}_PLANKS.get().defaultBlockState(), BlockBehaviour.Properties.copy(Blocks.OAK_STAIRS)));
public static final Supplier<Block> {{PREFIX_UPPER}}_SLAB = registerBlockWithItem("{{prefix_lower}}_slab",
        () -> new SlabBlock(BlockBehaviour.Properties.copy(Blocks.OAK_SLAB)));
public static final Supplier<Block> {{PREFIX_UPPER}}_FENCE = registerBlockWithItem("{{prefix_lower}}_fence",
        () -> new FenceBlock(BlockBehaviour.Properties.copy(Blocks.OAK_FENCE)));
public static final Supplier<Block> {{PREFIX_UPPER}}_FENCE_GATE = registerBlockWithItem("{{prefix_lower}}_fence_gate",
        () -> new FenceGateBlock(BlockBehaviour.Properties.copy(Blocks.OAK_FENCE_GATE), WoodType.ACACIA));
