---
name: terramod-helper
description: "This skill should be used when working on the TerrariaMine-MultiLoader Minecraft mod project, which adds Terraria content (weapons, armor, blocks, monsters) into Minecraft. Trigger when the user mentions adding items, blocks, entities, armor sets, weapons, tool materials, or any Terraria-related content to the mod. Also trigger for tasks involving mod registration patterns, multiloader architecture, data generators, or Terraria stat balancing."
---

# TerrariaMine Mod Development Skill

This skill provides comprehensive knowledge of the TerrariaMine-MultiLoader project architecture,
enabling efficient creation of items, blocks, entities, and other mod content.

## Project Overview

- **MOD ID**: `terrariamod`
- **Package**: `com.ricky.terrariamod`
- **Minecraft**: 1.20.1 (Fabric + Forge MultiLoader)
- **Architecture reference**: Read `references/architecture.md` for complete project structure
- **Stats reference**: Read `references/terraria-stats.md` for Terraria damage/defense values

## Core Workflow: Adding Content

When asked to add new content, always follow the complete registration checklist.
Read `references/architecture.md` for the full checklist per content type.

### Adding a New Item (Weapon/Tool/Material)

**Required steps (do ALL of these):**

1. Register in `common/.../item/ModItems.java`
   - Use code patterns from `assets/item-templates.java`
2. Add to creative tab in `common/.../item/ModCreativeTabs.java`
   - armor_tab for armor, tool_tab for weapons/tools, item_tab for materials
3. Add item model in `forge/.../data/ModItemModelProvider.java`
   - `handheldItem()` for weapons/tools, `simpleItem()` for everything else
4. Add texture at `common/src/main/resources/assets/terrariamod/textures/item/{id}.png`
   - Generate a 16x16 pixel art texture if the user does not provide one
5. Add translations to ALL 4 language files:
   - `lang/en_us.json` (English)
   - `lang/ja_jp.json` (Japanese)
   - `lang/zh_cn.json` (Chinese)
   - `lang/fr_fr.json` (French)

**For new tool materials**, also add to `ModToolMaterial.java` and update existing helper methods.
**For new armor sets**, also add to `ModArmorMaterials.java`, `ModArmorItem.MATERIAL_TO_EFFECT_MAP`, and create armor textures at `textures/models/armor/`.

### Adding a New Block

**Required steps (do ALL of these):**

1. Register in `common/.../block/ModBlocks.java` using `registerBlockWithItem()`
2. Add to `block_tab` in `ModCreativeTabs.java`
3. Add block state in `forge/.../data/ModBlockStateProvider.java`
4. Add loot table in `forge/.../data/ModLootTableProvider.java`
5. Add block texture at `textures/block/{id}.png`
6. Add translations to ALL 4 language files
7. Optionally: add tags, recipes, cutout rendering (for transparent blocks)

### Adding a New Entity/Monster

This is the most complex operation. Read `references/architecture.md` for the full 10-step checklist.

**Required steps (do ALL of these):**

1. Create Entity class in `common/.../entity/monster/{type}/{name}/`
   - Use templates from `assets/entity-templates.java`
   - Choose parent class based on type: Slime, Skeleton, Zombie, Bat, FlyingMob
2. Create Renderer class in the same package
3. Create Model class if using custom model (FlyingMob types)
4. Register EntityType in `common/.../entity/ModEntities.java`
5. Register attributes in **Fabric** `TerrariaMod.java`:
   ```java
   FabricDefaultAttributeRegistry.register(ModEntities.XXX.get(), XxxEntity.createAttributes());
   ```
6. Register attributes in **Forge** `ModEventBusEvents.java`:
   ```java
   event.put(ModEntities.XXX.get(), XxxEntity.createAttributes().build());
   ```
7. Register renderer in **Fabric** `TerrariaModClient.java`:
   ```java
   EntityRendererRegistry.register(ModEntities.XXX.get(), XxxRenderer::new);
   ```
   For custom models also:
   ```java
   EntityModelLayerRegistry.registerModelLayer(XxxModel.LAYER_LOCATION, XxxModel::createBodyLayer);
   ```
8. Register renderer in **Forge** `ClientModLifecycleEvents.java`:
   ```java
   EntityRenderers.register(ModEntities.XXX.get(), XxxRenderer::new);
   ```
   For custom models, also in `onRegisterLayerDefinitions`:
   ```java
   event.registerLayerDefinition(XxxModel.LAYER_LOCATION, XxxModel::createBodyLayer);
   ```
9. Add entity texture at `textures/entity/{name}.png`
10. Add translations to ALL 4 language files

## Important Conventions

### Naming
- Java fields: `UPPER_SNAKE_CASE` (e.g., `COBALT_SWORD`)
- Registry IDs: `lower_snake_case` (e.g., `"cobalt_sword"`)
- Class names: `PascalCase` (e.g., `CobaltSwordItem`)
- Entity packages: `monster/{type}/{name}/` (e.g., `monster/slime_type/ice_slime/`)

### Entity Type Selection Guide
| Terraria Enemy Type | MC Parent Class | Files Needed |
|---------------------|-----------------|--------------|
| Slime variants | `Slime` | Entity + Renderer |
| Skeleton/Armored | `Skeleton` | Entity + Renderer |
| Zombie/Mummy | `Zombie` | Entity + Renderer |
| Bat variants | `Bat` | Entity + Renderer |
| Flying (custom look) | `FlyingMob` | Entity + Model + Renderer |
| Boss | `FlyingMob` + `ServerBossEvent` | Entity + Model(s) + Renderer |

### Stat Balancing
When setting damage/health values, reference `references/terraria-stats.md` for existing values
and maintain proportional balance. Check the Terraria Wiki for official stats when adding
content from Terraria.

### MultiLoader Pattern
All game logic goes in `common/`. Platform-specific code (attribute registration, renderer binding)
must be added to BOTH `fabric/` and `forge/` modules. Never skip one platform.

### Language Files
Always update ALL 4 language files. Use format:
- Items: `"item.terrariamod.{id}": "Name"`
- Blocks: `"block.terrariamod.{id}": "Name"`
- Entities: `"entity.terrariamod.{id}": "Name"`

## Template Resources

- `assets/item-templates.java` — Code templates for swords, tools, armor, guns, magic staffs
- `assets/block-templates.java` — Code templates for ore, stone, wood, plants, building blocks
- `assets/entity-templates.java` — Code templates for Slime, Skeleton, Zombie, FlyingMob, Bat entities
